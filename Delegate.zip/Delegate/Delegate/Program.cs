﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Delegate
{
    class Program
    {
        delegate bool Check(int n);
        delegate void Write(string w);
        delegate int IntDelegate(int n, int n2);
        delegate void Empty();

        delegate void ReturnVoid<T>(T n);
        delegate U RetrunBool<in T,out U>(T n);

        //delegate string Lorem(string v, string v2);
        static void Main(string[] args)
        {
            #region queue stack FIFO

            Queue<int> queue = new Queue<int>();
            queue.Enqueue(5);
            queue.Enqueue(6);
            queue.Dequeue();
            //Console.WriteLine("peek");
            //Console.WriteLine(queue.Peek());
            //foreach (var item in queue)
            //{
            //    Console.WriteLine(item);
            //}
            //LIFO
            Stack<int> stack = new Stack<int>();
            stack.Push(5);
            stack.Push(6);

            //Console.WriteLine(stack.Peek());

            //foreach (var item in stack)
            //{
            //    Console.WriteLine(item);
            //}
            //Dictionary<string, string> dictionary = new Dictionary<string, string>();
            //dictionary.Add("Eyyub", "050");
            //dictionary.Add("Senan", "051");
            //dictionary.Add("Senan", "058");
            ////Console.WriteLine(dictionary["Senan"]);
            //foreach (var item in dictionary)
            //{
            //    Console.WriteLine($"{item.Key} {item.Value}");
            //}


            #endregion

            #region delegate
            //Console.WriteLine(IsOdd(new int[] { 1,5,8,9}));
            //Console.WriteLine(IsEven(new int[] { 1, 5, 8,4, 9 }));
            //Console.WriteLine(Sum(new int[] { 1, 5, -8, 4, 9 },IsDivided));
            //Console.WriteLine(Sum(new int[] { 1, 5, -8, 4, 9 }, IsNotDivide));
            //Console.WriteLine(Sum(new int[] { 1, 5, -8, 4, 9 },n=> { return n% 2!=0; }));

            //StringBuilder str = new StringBuilder();
            //StringBuilder str1 = str;

            //anonim
            //Write write = Print;
            //write += PrintLowerCase;
            //write += PrintUpperCase;
            //write += v => Console.WriteLine(v.Length);
            ////write += delegate (string w)
            //// {
            ////     Console.WriteLine(w.Length);
            //// };
            ////write.Invoke("Eyyub");
            //write("Yusif");

            //IntDelegate intDelegate=(num1,num2)=> {
            //    return num1 + num2;
            //};
            //Console.WriteLine(intDelegate(5, 5));
            //Empty empty = () =>
            //{
            //    Console.WriteLine("empty");
            //};
            //empty();

            //ReturnVoid<int> returnVoid = n =>
            //{
            //    Console.WriteLine(n);
            //};
            //returnVoid(5);
            //ReturnVoid<string> returnVoid = n =>
            //{
            //    Console.WriteLine(n);
            //};
            //returnVoid("test");

            //RetrunBool<int, int> retrunBool = (n, m) =>
            //{
            //    return n > m;
            //};
            //retrunBool(5, 6);

            //Action<int, int, string> action = (n, m, c) =>
            //{
            //    Console.WriteLine();
            //};
            //Func<string, string,int> func = (n, m) =>
            //  {
            //      return 5;
            //  };
            //Predicate<int> predicate = (n) =>
            //{
            //    return true;
            //};

            //List<int> numbers = new List<int>();
            //numbers.Add(2);
            //numbers.Add(5);
            //numbers.Add(8);
            //List<int>bigTwo= numbers.FindAll(n => { return n > 2; });
            // foreach (var item in bigTwo)
            // {
            //     Console.WriteLine(item);
            // }
            //int result=  numbers.Find(n => { return n == 2; });
            //  Console.WriteLine(result);
            #endregion

        }


        static void Print(string name)
        {
            Console.WriteLine(name);
        }
        static void PrintLowerCase(string name)
        {
            Console.WriteLine(name.ToLower());
        }
        static void PrintUpperCase(string name)
        {
            Console.WriteLine(name.ToUpper());
        }


        //static string Test(string w,string w2)
        //{
        //    return w + w2;
        //}
        static bool IsNotDivide(int num)
        {
            return num % 2 != 0;
        }
        static bool IsDivided(int num)
        {
            return num % 2 == 0;
        }
        static bool IsBigTwo(int num)
        {
            return num> 2;
        }


        static int Sum(int[] arr,Predicate<int> funk)
        {
            int result = 0;
            foreach (var item in arr)
            {
                if (funk(item))
                {
                    result += item;
                }
            }
            return result;
        }



        //static int IsOdd(int[] arr)
        //{
        //    int result = 0;
        //    foreach (var item in arr)
        //    {
        //        if (item % 2 != 0)
        //        {
        //            result += item;
        //        }
        //    }
        //    return result;
        //}
        //static int IsEven(int[] arr)
        //{
        //    int result = 0;
        //    foreach (var item in arr)
        //    {
        //        if (item % 2 == 0)
        //        {
        //            result += item;
        //        }
        //    }
        //    return result;
        //}
    }
}
